package vladyagl

interface OperatorFactory <T: Expression> {
    val name : String
    val leftPriority: Boolean
    val size: Int
    val symbol: String
    abstract fun create(vararg args: T): T
}