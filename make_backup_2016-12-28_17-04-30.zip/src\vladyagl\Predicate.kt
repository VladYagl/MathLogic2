package vladyagl

import java.util.*

open class Predicate(name: String, vararg termArgs: Term) : Expression(name) {
    val terms = termArgs

    override fun nodeEquals(other: Any?): Boolean {
        return if (other is Predicate) {
            name == other.name && Arrays.equals(terms, other.terms)
        } else {
            false
        }
    }

    override fun nodeToString(level: Int): String {
        return terms.joinToString(separator = ", ", prefix = name + "(", postfix = ")")
    }
}
